/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;


/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class PlayGround_v1Controller implements Initializable,ControlledScreen {
ScreensController myController = new ScreensController();
Constants consData = new Constants();
    /**
     * Initializes the controller class.
     */

@FXML
    private Label RoundLabel;
    @FXML
    private Label userNameLabel;
    @FXML
    private Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11;
    @FXML
    private ComboBox constantCheck,vowelsCheck;
    
    private Integer constantCount,VowelsCount;
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
    @FXML
    private void click_Btn1() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn2() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn3() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn4() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn5() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn6() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn7() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn8() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn9() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn10() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void click_Btn11() throws IOException {       
       System.out.print("Clicked");
       
    }
    
    @FXML
    private void BtnGenerateClick() throws IOException {       
       System.out.print("Clicked");
       
    }
    
    @FXML
    private void BtnsubmitClick() throws IOException {       
       System.out.print("Clicked");
       
    }
    @FXML
    private void BtnCanselClick() throws IOException {       
       System.out.print("Clicked");
    }
       
    

    @FXML
    private void Handle_close() throws IOException {
       Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }
    
    
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        constantCheck.getItems().addAll(
            "1","2","3","4","5","6","7","8"
        );
        vowelsCheck.getItems().addAll(
            "1","2","3","4","5","6","7","8"
        );//dropDown Values
        
        //Need To show default 2 Letters in btn1 and btn2
        btn1.setText("A");btn2.setText("M");
    }    
    
}
