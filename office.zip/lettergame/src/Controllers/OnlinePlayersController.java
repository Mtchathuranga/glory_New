/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;


import com.jfoenix.controls.JFXTreeTableColumn;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import Service.OnlineUser;

/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class OnlinePlayersController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    Constants consData = new Constants();
    /**
     * Initializes the controller class.
     */
    @FXML
    private ComboBox playerSelectCombo;    
    public String OnlinePlayerName;  
    @FXML
    private JFXTreeTableView<online> onlineTable;
    
    private ListView<String> onlineListView = new ListView<String>();
    ObservableList<String> DataList = FXCollections.observableArrayList("sasasasa","chathuranga","kdkdsklds");   
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
     @FXML
    private void handle_go_Back() throws IOException {
       
        myController.setScreen(Constants.MENU_SCREEN);
      
    }
     @FXML
    private void Handle_go() throws IOException { 
        myController.loadScreen(Constants.GAMEPLAY_SCREEN, Constants.GAMEPLAY_SCREEN_FXML);
        myController.setScreen(Constants.GAMEPLAY_SCREEN);      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }
       @FXML
    private void Handle_close() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }       
    }
    
     @FXML
    private void addValues(){
            // TODO
        JFXTreeTableColumn<online,String> name = new JFXTreeTableColumn("Player Name");
	name.setPrefWidth(380);
	
	name.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<online, String>, ObservableValue<String>>() {
	          
	    @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<online, String> param) {
                return param.getValue().getValue().name;
            }
        });
        
         ObservableList<online> online = FXCollections.observableArrayList();
		online.add(new online("kjkjkjkjkj"));
		online.add(new online("Nilesh Kadam"));
		online.add(new online("Shailesh Kadam"));
		online.add(new online("Subscirbers"));
                online.add(new online("Subscirbers"));
                online.add(new online("Subscirbers czxx"));
		
		final TreeItem<online> root = new RecursiveTreeItem<online>(online, RecursiveTreeObject::getChildren);
		onlineTable.getColumns().setAll(name);
		onlineTable.setRoot(root);
		onlineTable.setShowRoot(false);
    }
    
    private void getOnlinePlayers(){
            OnlineUser users = new OnlineUser();
            ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor();            
            exec.scheduleAtFixedRate(new Runnable() {
                
            @Override
            public void run() {
                      
                JSONArray arr = users.getAllOnlineUser();               
                for(int i = 0; i< arr.size(); i++){

                    JSONObject obj3 = (JSONObject)arr.get(i);
                    System.out.println(obj3.get("userName"));
              }
    
            }
            }, 0, 10, TimeUnit.SECONDS);
    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addValues();//showing online players
        getOnlinePlayers();
    }    
    
}

class online extends RecursiveTreeObject<online>{
                StringProperty name;
		public online(String name)
		{
			this.name = new SimpleStringProperty(name);
		}
}
