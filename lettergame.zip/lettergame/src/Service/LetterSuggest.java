/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import ApiLayer.Oxford;
import java.util.Random;

/**
 *
 * @author namdy
 */
public class LetterSuggest {
    
    private Oxford ox = new Oxford();
    
    /*steps of the intigration with ui
    
        step 01: call the method one to genarate random numbers
        (after the random number genarates ui side need to set timer (Java thread to give 1 minutes to the user to select word)
    
        step 02: create random consonononts
    
        step 03: create random vowels
    
        step 04: use Islenghth() validate function to the validate lenghth
    
        step 05: use the isEnglishword  function to validate it's a english word
        
    
    
    then, call the method number two for the validate user entered word's length
    
        step 
    
    
    */
    
    
    // 01. randoms latter create 
    
    public static char[] letterRandom() 
    {
      char randomLetter[] = new char[3];
      Random r = new Random();
      String alphabet = "ABCDEFGHIJKLMNOPQRSTUVXYZ";
      for (int i = 0; i < 3; i++)
      {
 
           randomLetter[i] = alphabet.charAt(r.nextInt(alphabet.length()));
        
      }
       return randomLetter;
    }
    // 02. create random consononats
    public static char[] consononants(int amount){
         char[] randomConsononants = new char[amount];
         Random r = new Random();
         
        String consononantsLetters = "BCDFGHJKLMNPQRSTVXZWY";
        for (int i = 0; i < amount; i++){
            randomConsononants[i] = consononantsLetters.charAt(r.nextInt(consononantsLetters.length()));
        }
        
        return randomConsononants;
    }
    
    // 03 vowels
    
    public static char[] vowels(int amount) {
    
        char[] randomVowels = new char[amount];
        Random r = new Random();
         
        String VowelsLetters = "AEIOU";
        for (int i = 0; i < amount; i++){
            
            randomVowels[i] = VowelsLetters.charAt(r.nextInt(VowelsLetters.length()));
        }
        
        return randomVowels;
    }
    
    //04. before the user sumbmit the word this must call to validate it's length
    
    public boolean islenghtValidate(String latter)
    {
        if(latter.length()<= 11)
            return true;
        return false;
    }
    // 05. before the user sumbmit the word this must call to validate it's english
    public boolean isEnglishWord(String word)
    {
        if(ox.httpGet(word))
                return true;
        return false;  
    }
    
    // validate the user entered word according to the givvern latter
 }

