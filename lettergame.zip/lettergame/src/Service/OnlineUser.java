/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import ApiLayer.OnlineUserApi;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author namdy
 */
public class OnlineUser {
    
    private  OnlineUserApi online;
    
    /* HOW TO USE THIS FUNCTION IN UI
    
    NOTE: this fuction call in 20sec thread;
           ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor();
exec.scheduleAtFixedRate(new Runnable() {
  @Override
  public void run() {
      JSONArray arr = getAllOnlineUser();
    for(int i = 0; i< arr.length(), i++){
    
        JSONObject obj3 = (JSONObject)array.get(i);
           System.out.println(obj3.get("userName"));
    }
    
    }
}, 0, 20, TimeUnit.SECONDS);
    
        to get all user

    */
    
            
    public JSONArray getAllOnlineUser(){
    
        try {
            
            JSONArray arr = online.getAllOnlineUser();
            return arr;
            
        } catch (ProtocolException ex) {
            Logger.getLogger(OnlineUser.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } catch (IOException ex) {
            Logger.getLogger(OnlineUser.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        
        
    }

}
