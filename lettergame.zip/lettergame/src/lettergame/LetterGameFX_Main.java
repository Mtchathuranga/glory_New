/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lettergame;

import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.io.IOException;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import lettergame.Constants;
import lettergame.PropertyHandler;
import lettergame.ScreensController;
import java.lang.reflect.*;
import Controllers.RegisterController;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

/**
 *
 * @author Mtchathuranga
 */
public class LetterGameFX_Main extends Application {
    
    private double xOffset = 0;
    private double yOffset = 0;
    AnchorPane rootPane;
    
    @Override
    public void start(Stage stage) throws IOException {
       

       
//       Parent root = FXMLLoader.load(getClass().getResource("../Views/Register.fxml"));
//       stage.initStyle(StageStyle.UNDECORATED); 
//       BorderPane pane = new BorderPane();
//        
//       root.setOnMousePressed(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent event) {
//                xOffset = event.getSceneX();
//                yOffset = event.getSceneY();
//            }
//        });
//        root.setOnMouseDragged(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent event) {
//                stage.setX(event.getScreenX() - xOffset);
//                stage.setY(event.getScreenY() - yOffset);
//            }
//        });      
//       
//        Scene scene = new Scene(root);
//        
//        stage.setScene(scene);
//        stage.show();
        
        
        
        
                PropertyHandler propertyHandler = new PropertyHandler();        
                 // load screens into mainScreen Controller
		ScreensController mainContainer = new ScreensController();
		mainContainer.loadScreen(Constants.Login_SCREEN, Constants.Login_SCREEN_FXML);
		mainContainer.loadScreen(Constants.REGISTER_SCREEN, Constants.REGISTER_SCREEN_FXML);
		mainContainer.loadScreen(Constants.MENU_SCREEN, Constants.MENU_SCREEN_FXML);
		mainContainer.loadScreen(Constants.GAMEPLAY_SCREEN, Constants.GAMEPLAY_SCREEN_FXML);
                mainContainer.loadScreen(Constants.GAMEPLAY_SCREEN_V1, Constants.GAMEPLAY_SCREEN_FXML_V1);
                mainContainer.loadScreen(Constants.Board_SCREEN, Constants.Board_SCREEN_FXML);
                mainContainer.loadScreen(Constants.Option_SCREEN, Constants.Option_SCREEN_FXML);
                mainContainer.loadScreen(Constants.OnlinePlayers_SCREEN, Constants.OnlinePlayers_SCREEN_FXML);

		mainContainer.setScreen(Constants.MENU_SCREEN);
                stage.initStyle(StageStyle.UNDECORATED); 
                BorderPane pane = new BorderPane();
                
                mainContainer.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                 public void handle(MouseEvent event) {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                }
                });
                mainContainer.setOnMouseDragged(new EventHandler<MouseEvent>() {
                @Override
                    public void handle(MouseEvent event) {
                     stage.setX(event.getScreenX() - xOffset);
                     stage.setY(event.getScreenY() - yOffset);
                    }
                });   

		Group root = new Group();
		root.getChildren().addAll(mainContainer);
		Scene scene = new Scene(root);
		//stage.setWidth(Integer.parseInt(propertyHandler.getProperty("preWindowWidth")));
		//stage.setHeight(Integer.parseInt(propertyHandler.getProperty("preWindowHeight")));
		stage.setTitle("Letter-By-Letter");		
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();       
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
