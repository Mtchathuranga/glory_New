/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;

/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class OnlinePlayersController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    Constants consData = new Constants();

    /**
     * Initializes the controller class.
     */
    @FXML
    private ComboBox playerSelectCombo;    
    public String OnlinePlayerName;    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
     @FXML
    private void handle_go_Back() throws IOException {
       
        myController.setScreen(Constants.MENU_SCREEN);
      
    }
     @FXML
    private void Handle_go() throws IOException {        
        consData.OnlinePlayerName = playerSelectCombo.getValue().toString();
        
         myController.loadScreen(Constants.GAMEPLAY_SCREEN, Constants.GAMEPLAY_SCREEN_FXML);
        System.out.println(consData.OnlinePlayerName);
        myController.setScreen(Constants.GAMEPLAY_SCREEN);      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }
       @FXML
    private void Handle_close() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }       
    }
    
     @FXML
    private void addComboBoxValues(){
        //Need to show Online Players
        playerSelectCombo.getItems().addAll(
            "Option 1",
            "Option 2",
            "Option 3"
        );

    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addComboBoxValues();//showing online players
    }    
    
}
