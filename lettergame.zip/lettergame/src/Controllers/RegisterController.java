/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;
import javafx.fxml.*;


/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class RegisterController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    /**
     * Initializes the controller class.
     */
    @FXML
    private  TextField text_UserName ;
    @FXML
    private  TextField text_Email ;
    @FXML
    private  PasswordField text_COnfirmPasword ;
    @FXML
    private  PasswordField text_PasswordCreate ;
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
     @FXML
    private void handle_go_Back() throws IOException {
        myController.setScreen(Constants.Login_SCREEN); 
      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        } 
       
    }
       @FXML
    private void Handle_close() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        } 
       
    }
    
         @FXML
    private void Handle_Register() throws IOException {
        System.out.println("saasa");        
         System.out.println(text_UserName.getText());
        System.out.println(text_Email.getText().toString());
        System.out.println(text_COnfirmPasword.getText());
        System.out.println(text_PasswordCreate.getText());
        //myController.setScreen(Constants.OnlinePlayers_SCREEN); 
        
        //Need to handle Register
       
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
