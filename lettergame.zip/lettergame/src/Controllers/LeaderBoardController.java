/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTreeTableColumn;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import java.util.Optional;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.util.Callback;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;


/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class LeaderBoardController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();

    /**
     * Initializes the controller class.
     */
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
    
    @FXML
    private JFXTreeTableView<Person> table;
       
     @FXML
    private void handle_go_Back() throws IOException {
        myController.setScreen(Constants.MENU_SCREEN);
      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }
       @FXML
    private void Handle_close() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        JFXTreeTableColumn<Person,String> name = new JFXTreeTableColumn("Player Name");
	name.setPrefWidth(301);
        name.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<Person, String>, ObservableValue<String>>() {
	          
	@Override
        public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<Person, String> param) {
              return param.getValue().getValue().name;
        }
        });
                        
        JFXTreeTableColumn<Person,String> age = new JFXTreeTableColumn("Score");
	age.setPrefWidth(251);
	
	age.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<Person, String>, ObservableValue<String>>() {
	          
	    @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<Person, String> param) {
                return param.getValue().getValue().age;
            }
        });		

                
                ObservableList<Person> person = FXCollections.observableArrayList();
		person.add(new Person("Genius Coders","20"));
		person.add(new Person("Nilesh Kadam","20"));
		person.add(new Person("Shailesh Kadam","18"));
		person.add(new Person("Subscirbers","21"));
                person.add(new Person("Subscirbers","21"));
                person.add(new Person("Subscirbers","21"));
		
		final TreeItem<Person> root = new RecursiveTreeItem<Person>(person, RecursiveTreeObject::getChildren);
		table.getColumns().setAll(name,age);
		table.setRoot(root);
		table.setShowRoot(false);
       
    }    
    
}

class Person extends RecursiveTreeObject<Person>{
		StringProperty name;
		StringProperty age;
		
		
		public Person(String name,String age)
		{
			this.name = new SimpleStringProperty(name);
			this.age  = new SimpleStringProperty(age);
			
			
		}
		
		
}
