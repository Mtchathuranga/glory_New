/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author namdy
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Metadata {

@SerializedName("provider")
@Expose
private String provider;

public String getProvider() {
return provider;
}

public void setProvider(String provider) {
this.provider = provider;
}

}