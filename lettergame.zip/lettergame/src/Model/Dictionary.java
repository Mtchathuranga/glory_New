/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author namdy
 */
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sun.xml.internal.ws.api.addressing.WSEndpointReference.Metadata;

public class Dictionary {

@SerializedName("metadata")
@Expose
private Metadata metadata;
@SerializedName("results")
@Expose
private List<Result> results = null;

public Metadata getMetadata() {
return metadata;
}

public void setMetadata(Metadata metadata) {
this.metadata = metadata;
}

public List<Result> getResults() {
return results;
}

public void setResults(List<Result> results) {
this.results = results;
}

}