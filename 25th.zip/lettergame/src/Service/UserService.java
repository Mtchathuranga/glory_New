/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import ApiLayer.UserApi;
import Model.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author namdy
 */
public class UserService {
    
    private  UserApi user = new UserApi();   
    // user signin
    public String userName;
    public String password;
    public  boolean signin(String userName, String password) throws IOException{ 
        
        User u = new User();
        
        boolean a=  user.signin(userName, password);
        userName = u.getUserName();
        return a;  
        }
    
    public boolean signup(String userName, String Password) {return true;}
    
    }
