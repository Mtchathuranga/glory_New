/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;
import Service.LetterSuggest;
import javafx.application.Platform;
import javafx.concurrent.Task;
import Service.CountDownClock;
import lettergame.PropertyHandler;


/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class PlayGroundController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    Constants consData = new Constants();
    LetterSuggest letterGen = new LetterSuggest();   
    /**
    * Initializes the controller class.
    */ 
      
              
    @FXML
    private Label RoundLabel,userNameLabel,wordLabel,txt_timer;    
    @FXML
    private Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11,btnSTart,btnGenerate,btnSubmit;
    @FXML
    private ComboBox constantCheck,vowelsCheck;
    
    //Important
    private Integer constantCount,VowelsCount;
    private int round ;
    private String submit_status = "PENDING";
    private String player_word = "";
    private int points , hints = Integer.parseInt(new PropertyHandler().getProperty("gameMaxhints"));
    
    private String tempWord;
    private String RandomLetters ;
    
    private char[] charDefaultArray ,charConstantArray , charVowelsArray;
    private String[] defaultLetters;
    
    private boolean status = false , isCorrect = true ;
    
    private static int countDownTime = Integer.parseInt(new PropertyHandler().getProperty("countDownTime"));
    
    public void setScreenParent(ScreensController screenPage) {
	// TODO Auto-generated method stub
	myController = screenPage;
    }
    @FXML
    private void combineLetter(Button btnName) throws IOException { 
       tempWord = wordLabel.getText().toString(); 
       if(tempWord.length() < 11){
           wordLabel.setText(tempWord+btnName.getText());       
       }else{
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Maximum length achived");
            alert.setHeaderText("Please Submit ! ");
            alert.showAndWait();      
       }
      
       
    }
    @FXML
    private void click_Btn1() throws IOException { 
       combineLetter(btn1);
    }
    
    @FXML
    private void BtnClear() throws IOException {        
       tempWord = wordLabel.getText().toString();
       tempWord = tempWord.substring(0, tempWord.length() - 1);
       wordLabel.setText(tempWord);       
    }
    @FXML
    private void click_Btn2() throws IOException { 
       combineLetter(btn2);
       
    }
    @FXML
    private void click_Btn3() throws IOException { 
       combineLetter(btn3);
       
    }
    @FXML
    private void click_Btn4() throws IOException { 
      combineLetter(btn4);
       
    }
    @FXML
    private void click_Btn5() throws IOException { 
       combineLetter(btn5);
       
    }
    @FXML
    private void click_Btn6() throws IOException {  
       combineLetter(btn6);
       
    }
    @FXML
    private void click_Btn7() throws IOException { 
       combineLetter(btn7);
       
    }
    @FXML
    private void click_Btn8() throws IOException { 
       combineLetter(btn8);
       
    }
    @FXML
    private void click_Btn9() throws IOException { 
       combineLetter(btn9);
       
    }
    @FXML
    private void click_Btn10() throws IOException { 
       combineLetter(btn10);
       
    }
    @FXML
    private void click_Btn11() throws IOException { 
       combineLetter(btn11);       
    }
    
    @FXML
    private void BtnGenerateClick() throws IOException { 
            try {                
            if(constantCheck.getValue() == null && vowelsCheck.getValue() == null ){
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Wrong inputs");
                alert.setHeaderText("Please select constant and Vowels! ");
                alert.showAndWait();
            }else{  
                if(constantCheck.getValue() == null ){                   
                    VowelsCount = Integer.parseInt(vowelsCheck.getValue().toString());                   
                }else if(vowelsCheck.getValue() == null){
                    constantCount = Integer.parseInt(constantCheck.getValue().toString()); 
                    if(constantCount == 8 ){
                        charConstantArray = letterGen.consononants(constantCount);
                        String  result2 = new String(charConstantArray);
                        String [] array2 = result2.split("");
                        btn4.setText(array2[0]);btn5.setText(array2[1]);btn6.setText(array2[2]);btn7.setText(array2[3]);
                        btn8.setText(array2[4]);btn9.setText(array2[5]);btn10.setText(array2[6]);btn11.setText(array2[7]);
                        constantCheck.getSelectionModel().clearSelection();
                        vowelsCheck.getSelectionModel().clearSelection();
                    }else{
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Wrong inputs");
                        alert.setHeaderText("Please select 8 letters ! ");  
                        alert.showAndWait();
                        constantCheck.getSelectionModel().clearSelection();
                        vowelsCheck.getSelectionModel().clearSelection();
                    }
                }else{
                    constantCount = Integer.parseInt(constantCheck.getValue().toString());
                    VowelsCount = Integer.parseInt(vowelsCheck.getValue().toString());  
                    if(constantCount+VowelsCount != 8){
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Wrong inputs");
                        alert.setHeaderText("Word Level Must Be 11.Vowels + Constant values should be 8 ! ");  
                        alert.showAndWait(); 
                        constantCheck.getSelectionModel().clearSelection();
                        vowelsCheck.getSelectionModel().clearSelection();                        
                    }else{
                        charConstantArray = letterGen.consononants(constantCount);
                        charVowelsArray = letterGen.vowels(VowelsCount);
                        String  result1 = new String(charVowelsArray);
                        String [] array1 = result1.split("");
                        
                        String  result2 = new String(charConstantArray);
                        String [] array2 = result2.split("");
                        
                        if(VowelsCount == 1){                            
                            btn4.setText(array1[0]);btn5.setText(array2[0]);btn6.setText(array2[1]);btn7.setText(array2[2]);
                            btn8.setText(array2[3]);btn9.setText(array2[4]);btn10.setText(array2[5]);btn11.setText(array2[6]);                        
                        }else if(VowelsCount == 2){
                            btn4.setText(array1[0]);btn5.setText(array1[1]);btn6.setText(array2[0]);btn7.setText(array2[1]);
                            btn8.setText(array2[2]);btn9.setText(array2[3]);btn10.setText(array2[4]);btn11.setText(array2[5]);                            
                        }else if(VowelsCount == 3){
                            btn4.setText(array1[0]);btn5.setText(array1[1]);btn6.setText(array1[2]);btn7.setText(array2[0]);
                            btn8.setText(array2[1]);btn9.setText(array2[2]);btn10.setText(array2[3]);btn11.setText(array2[4]);                            
                        }else if(VowelsCount == 4){
                            btn4.setText(array1[0]);btn5.setText(array1[1]);btn6.setText(array1[2]);btn7.setText(array1[3]);
                            btn8.setText(array2[0]);btn9.setText(array2[1]);btn10.setText(array2[2]);btn11.setText(array2[3]);                            
                        }else if(VowelsCount == 5){
                            btn4.setText(array1[0]);btn5.setText(array1[1]);btn6.setText(array1[2]);btn7.setText(array1[3]);
                            btn8.setText(array1[4]);btn9.setText(array2[0]);btn10.setText(array2[1]);btn11.setText(array2[2]);
                        }
                        constantCheck.getSelectionModel().clearSelection();
                        vowelsCheck.getSelectionModel().clearSelection();
                    }
                } 
            }            
        } catch (Exception e) {
            e.printStackTrace();
        }
              
    }
    
    	private void clockStart() {            
		final CountDownClock clock = new CountDownClock();
		Task<Void> task = new Task<Void>() {
			@Override
			public Void call() throws Exception {                            
				while (status && countDownTime > 0) {
					Platform.runLater(new Runnable() {
						public void run() {
							txt_timer.setText(clock.getTimeLeft(countDownTime).toString());                                                       
						}
					});
					countDownTime--;
					/**
					 * Check auto submit details
					 */
					autoSubmit();
					Thread.sleep(1000);
				}
				return null;
			}
		};
		Thread th = new Thread(task);
		th.setDaemon(true);
		th.start();
	}
        
    private void autoSubmit() {
        if (countDownTime == 0) {
        
        }   
    }
    
    @FXML
    private void BtnsubmitClick() throws IOException {  
        if(wordLabel.getText().length() <= 1){
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Wrong Word");
            alert.setHeaderText("Word length must be greater than 1! ");
            alert.showAndWait();       
        }else{           
           //isCorrect = letterGen.isEnglishWord(wordLabel.getText());
           if(!isCorrect){
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Wrong Word");
                alert.setHeaderText(wordLabel.getText()+" - Is Not a valid ENglish word! ");
                alert.showAndWait();
           }else{
                 player_word = wordLabel.getText();
                
                 //Need to generate points and move to next Round
                 
                 Integer mark = 200;//out from generate points 
                 
                 consData.InfoData.replace("tempMark", mark.toString());
                 
                 Integer tempM = Integer.parseInt(consData.InfoData.get("tempFullMark"))+ mark;
                 consData.InfoData.replace("tempFullMark", tempM.toString());
                              
                 myController.loadScreen(Constants.NextRound_SCREEN, Constants.NextRound_FXML);
                 myController.setScreen(Constants.NextRound_SCREEN);
           }       
       }     
       
    }
    
    private void checkRound(){
                                 
                    Integer temp = Integer.parseInt(consData.InfoData.get("tempRound"));
                    temp = temp+1;
                    System.out.println(temp);
                    consData.InfoData.replace("tempRound", temp.toString());
                    System.out.println("zzzz"+consData.InfoData.get("tempRound"));               
                
        
    
    }
    
    
    @FXML
    private void BtnCanselClick() throws IOException { 
        wordLabel.setText("");
       
       
       
    }  
    @FXML
    private void btnSTart_play() throws IOException {
          
        status = true;
        btnGenerate.setDisable(false);
        btnSTart.setVisible(false);
        txt_timer.setVisible(true);
        btnSubmit.setDisable(false);        
        clockStart();
       
    }
    

    @FXML
    private void Handle_close() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }
      
    private void generateRandom(){ 
        try {
             charDefaultArray = letterGen.letterRandom();        
             String  result = new String(charDefaultArray);
             String [] array = result.split("");             
             btn1.setText(array[0]);
             btn2.setText(array[1]);
             btn3.setText(array[2]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        generateRandom();//generate random 3 letters
        checkRound();    
        wordLabel.setText("");
        txt_timer.setText("");
        txt_timer.setVisible(false);
        btnSTart.setVisible(true);
        btnSubmit.setDisable(true);
        btnGenerate.setDisable(true);
        System.out.println("Player Name Is :"+consData.OnlinePlayerName);  
        RoundLabel.setText(consData.InfoData.get("tempRound"));
        constantCheck.getItems().addAll(
            "1","2","3","4","5","6","7","8"
        );
        vowelsCheck.getItems().addAll(
            "1","2","3","4","5"
        );//dropDown Values
        
        
    }    
    
}
