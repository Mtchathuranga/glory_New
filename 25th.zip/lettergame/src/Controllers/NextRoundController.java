/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import lettergame.Constants;
import lettergame.ControlledScreen;
import lettergame.PropertyHandler;
import lettergame.ScreensController;

/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class NextRoundController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    Constants consData = new Constants();

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button btnNext;
    @FXML
    private Label labelMarks,pastRound;
    private int  hints = Integer.parseInt(new PropertyHandler().getProperty("gameMaxhints"));
    
    public  String tempMarks,tempPast;
    
    public void setTempvalues(String marks,String past){
        tempMarks = marks;
        tempPast = "Round "+past;    
    }
            
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
     @FXML
    private void btnNext_CLick() throws IOException {
        Integer t = Integer.parseInt(consData.InfoData.get("tempRound"));
        if( t >= hints){
            //showing output screen with marks and winner
            myController.loadScreen(Constants.OutPut_SCREEN, Constants.OutPut_SCREEN_FXML);
            myController.setScreen(Constants.OutPut_SCREEN);
        
        }else{
            myController.loadScreen(Constants.GAMEPLAY_SCREEN, Constants.GAMEPLAY_SCREEN_FXML);
            myController.setScreen(Constants.GAMEPLAY_SCREEN);
        
        }
    
    }
    @FXML
    private void Handle_close() throws IOException {
        //need to show dialog box
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }
       
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        labelMarks.setText(consData.InfoData.get("tempMark"));
        pastRound.setText(consData.InfoData.get("tempRound"));
    }    
    
}
