/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ApiLayer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author namdy
 */
public class OnlineUserApi {
    
    private final  String ONLINE_USER_URL = "http://dagametest.azurewebsites.net/api/UserControl/OnlineUser";
    private JSONArray array;
    public JSONArray getAllOnlineUser() throws MalformedURLException, ProtocolException, IOException{
   
        URL obj = new URL(ONLINE_USER_URL);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        int responseCode = con.getResponseCode();
        BufferedReader in = new BufferedReader(
        new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
        	response.append(inputLine);
        }
        in.close();
        
        JSONParser parser = new JSONParser();
        JSONObject myResponse = new JSONObject();

        Object obj2;
        try {
            obj2 = parser.parse(response.toString());
            array = (JSONArray)obj2;
         
        } catch (ParseException ex) {
            Logger.getLogger(OnlineUserApi.class.getName()).log(Level.SEVERE, null, ex);
        }

       return array; 
        
       }
       
    
}
