/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;

/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class Main_MenuController implements Initializable,ControlledScreen {
    
    ScreensController myController = new ScreensController();
    /**
     * Initializes the controller class.
     */
     @FXML
    private void Handle_close() throws IOException {
        
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }       
       
       
    }
    
        @FXML
    private void handle_option() throws IOException {
       System.out.println("You clicked handle_option!");
       myController.setScreen(Constants.Option_SCREEN);
       
    }
    
          @FXML
    private void handle_HowtoPlay() throws IOException {
       System.out.println("You clicked me!");       
       
    }
    
          @FXML
    private void handle_PlayNow() throws IOException {
       System.out.println("You clicked handle_PlayNow!");
       myController.setScreen(Constants.Login_SCREEN);      
       
    }
           @FXML
    private void handle_Quit() throws IOException {        
        System.out.println("You clicked me!");
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        }  
       
    }
            @FXML
    private void handle_Board() throws IOException {
        //need to show dialog box
      System.out.println("You clicked handle_Board!");
      myController.setScreen(Constants.Board_SCREEN);
       
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
  
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
                System.out.println(myController);
                
    }
    
}
