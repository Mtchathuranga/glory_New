/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;
import Service.UserService;



/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class LogInController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    UserService userServiceData= new UserService();
    Constants consData = new Constants();
    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField text_UserName;
    @FXML
    private PasswordField text_UserPasword;
    
    private boolean logStatus;
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
        @FXML
    private void handle_go_Back() throws IOException {        
        myController.setScreen(Constants.MENU_SCREEN);      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        } 
       
    } 
    
       @FXML
    private void Handle_close() throws IOException {        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exist....");
        alert.setHeaderText("Look, You are going to leave the game");
        alert.setContentText("Are you ok with this?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            // ... user chose CANCEL or closed the dialog
        } 
       
    }
    
         @FXML
    private void Handle_sign_In() throws IOException {
        if(this.text_UserName.getText() !=null && this.text_UserPasword.getText() != null ){
            userServiceData.signin( this.text_UserName.getText(), this.text_UserPasword.getText());
            if(!logStatus){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Log In Failed");
                alert.setHeaderText("Please Enter Corret Values.if not register,Please register ! ");
                alert.showAndWait(); 
                text_UserName.setText("");text_UserPasword.setText("");
            }else{
                consData.OnlinePlayerName = text_UserName.getText().toString();
                myController.setScreen(Constants.OnlinePlayers_SCREEN);            
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Log In Failed");
            alert.setHeaderText("Please Enter values ! ");
            alert.showAndWait();        
        }
    }
          @FXML
    private void NavigateToRegister() throws IOException {
        
        myController.setScreen(Constants.REGISTER_SCREEN);
       
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        text_UserName.setText("");text_UserPasword.setText("");
    }   
    
    
    
}
