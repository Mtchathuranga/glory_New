package lettergame;

public class Constants {
	// All screens references
	public static final String Login_SCREEN = "Login";
	public static final String Login_SCREEN_FXML = "../Views/LogIn.fxml";
	public static final String MENU_SCREEN = "Menu";
	public static final String MENU_SCREEN_FXML = "../Views/Main_Menu.fxml";
	public static final String GAMEPLAY_SCREEN = "GameView";
	public static final String GAMEPLAY_SCREEN_FXML = "../Views/PlayGround.fxml";
   
        
	public static final String REGISTER_SCREEN = "Register";
	public static final String REGISTER_SCREEN_FXML = "../Views/Register.fxml";
        public static final String Board_SCREEN = "LBoard";
	public static final String Board_SCREEN_FXML = "../Views/LeaderBoard.fxml";
        public static final String Option_SCREEN = "Option";
	public static final String Option_SCREEN_FXML = "../Views/Option.fxml";
        public static final String OnlinePlayers_SCREEN = "OnlinePlayers";
	public static final String OnlinePlayers_SCREEN_FXML = "../Views/OnlinePlayers.fxml";
	public static final String LETTER = "letter";
	public static final String VOWEL = "vowel";
	public static final String CONSONANT = "consonant";
        public static String OnlinePlayerName = "Test";
}
